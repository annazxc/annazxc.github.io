#ifndef RunStatus_hpp
#define RunStatus_hpp

enum class RunStatus {
    Error,
    Ready,
    Running,
    Done
};

#endif 
