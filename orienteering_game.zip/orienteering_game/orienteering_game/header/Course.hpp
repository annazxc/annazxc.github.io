#ifndef Course_hpp
#define Course_hpp
#include <vector>
#include <string>
#include <iostream>
enum class DifficultyLevel { EASY=1, MEDIUM, HARD };

class Course {
public:
    Course(const std::string& name);
    Course(const std::string& name,DifficultyLevel level, const std::vector<int>& waypoints);
    virtual ~Course() = default;
    virtual std::string getName() const;
    const std::vector<int>& getWaypoints() const;
    virtual bool checkWaypoint(const class IDStick& id, int wayptIdx)const;
    
    virtual std::tuple<int, std::string, std::string> ResultTable(const std::vector<std::chrono::system_clock::time_point>& timestamps) const;
    
    DifficultyLevel getDifficultyLevel();
    static std::string difficultyLevelToString(DifficultyLevel level);
    
protected:
    std::string Name;
    DifficultyLevel Level;
    std::vector<int> Waypoints;

};

#endif

