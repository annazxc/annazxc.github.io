#ifndef running_hpp
#define running_hpp
#include "raylib.h"

class OrienteeringGame {
public:
    OrienteeringGame(int screenWidth, int screenHeight)
        : screenWidth(screenWidth), screenHeight(screenHeight)
    {
        InitWindow(screenWidth, screenHeight, "Wilderness Navigation: Orienteering Run");
        //void InitCamera(Camera& camera, float fovy, Vector3 position, Vector3 target);
       
        InitCamera(cameraPlayer1, 45.0f, (Vector3){ 0, 1.0f, -3.0f }, (Vector3){ 0, 1.0f, 0 });
        // void InitRenderTexture(RenderTexture2D& renderTexture, int width, int height);
        
        InitRenderTexture(screenPlayer1, screenWidth / 2, screenHeight);

        InitCamera(cameraPlayer2, 45.0f, (Vector3){ -3.0f, 3.0f, 0 }, (Vector3){ 0, 3.0f, 0 });
        InitRenderTexture(screenPlayer2, screenWidth / 2, screenHeight);

        splitScreenRect = { 0.0f, 0.0f, static_cast<float>(screenPlayer1.texture.width), static_cast<float>(-screenPlayer1.texture.height) };

        count = 5;
        spacing = 4.0f;

        SetTargetFPS(80);
        
    }

    ~OrienteeringGame() {
        UnloadRenderTexture(screenPlayer1);
        UnloadRenderTexture(screenPlayer2);
    }

    void Run() {
        while (!WindowShouldClose()) {
            // void ProcessInput(Camera& camera);

            ProcessInput(cameraPlayer1);
            ProcessInput(cameraPlayer2);
            DrawGame();
        }
        CloseWindow();
    }

private:
    int screenWidth;
    int screenHeight;

    Camera cameraPlayer1;
    RenderTexture2D screenPlayer1;

    Camera cameraPlayer2;
    RenderTexture2D screenPlayer2;

    Rectangle splitScreenRect;

    int count;
    float spacing;

    float waypointG_X = 10;
    float waypointG_Y = 10;
    float waypointG_Z = 10;
    float waypointP_X = 20;
    float waypointP_Y = 20;
    float waypointP_Z = 0;

    void InitCamera(Camera& camera, float fovy, Vector3 position, Vector3 target);
    void InitRenderTexture(RenderTexture2D& renderTexture, int width, int height);
    void ProcessInput(Camera& camera);
    void DrawGame();
   
};


#endif
