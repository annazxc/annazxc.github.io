#ifndef ScoreCourse_hpp
#define ScoreCourse_hpp
#include "Course.hpp"
#include <chrono>

class ScoreCourse : public Course {
public:
    ScoreCourse(const std::string& name,DifficultyLevel& level, const std::vector<int>& waypoints, const std::vector<int>& points, const std::chrono::seconds& maxTime, double penalty);
    ~ScoreCourse() override = default;

    bool checkWaypoint(const class IDStick& id, int wayptIdx) const override;
    
private:
    std::vector<int> Points;
    std::chrono::seconds MaxTime;
    std::chrono::seconds TimeLimit;
    double TimePenalty;
};

#endif
