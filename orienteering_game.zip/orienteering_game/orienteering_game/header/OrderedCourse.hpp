#ifndef OrderedCourse_hpp
#define OrderedCourse_hpp
#include "Course.hpp"

class OrderedCourse : public Course {
public:
    OrderedCourse(const std::string& name, DifficultyLevel& lvl, const std::vector<int>& waypts);
    ~OrderedCourse() override = default;
    
    void Display() const;
    bool checkWaypoint(const class IDStick& id, int wayptIdx) const override;
    std::tuple<int, std::string, std::vector<std::vector<int>>> ResultTable(const std::vector<int>& t) const ;
private:
    std::vector<std::chrono::system_clock::time_point> Timestamps;

};

#endif

