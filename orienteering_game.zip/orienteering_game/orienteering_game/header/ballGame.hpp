#ifndef ballGame_hpp
#define ballGame_hpp
#include<raylib.h>
class Paddle;
class Ball {
public:
    float x, y;
    float speedX, speedY;
    float radius;

    Ball(float startX, float startY, float startSpeedX, float startSpeedY, float startRadius)
        : x(startX), y(startY), speedX(startSpeedX), speedY(startSpeedY), radius(startRadius) {}
    void HandleCollisionL(const Paddle& paddle);
    void HandleCollisionR(const Paddle& paddle);
    void Draw() const{
        DrawCircle(static_cast<int>(x), static_cast<int>(y), radius, WHITE);
        }
    void Update();
    void Reset();
};


class Paddle {
public:
    float x, y;
    float speed;
    float width, height;

    Paddle(float startX, float startY, float startSpeed, float startWidth, float startHeight)
        : x(startX), y(startY), speed(startSpeed), width(startWidth), height(startHeight) {}
    void HandleInputL();
    void HandleInputR();
    Rectangle GetRect() const {
        return Rectangle{ x - width / 2, y - height / 2, 10, 100 };
    }

    void Draw() const {
        DrawRectangleRec(GetRect(), WHITE);
    }

    void DrawWithColor(Color color) const {
        DrawRectangleRec(GetRect(), color);
    }
};

class Game{
public:
    int Run();
    void Update();
    void HandleScore(Ball& ball, int& points, const char*& winnerText, bool& pointAdded);
    void DrawGame(const Ball& ball, const Paddle& leftPaddle, const Paddle& leftPaddle1,
             const Paddle& leftPaddle2, const Paddle& rightPaddle, int points, const char* winnerText);
    int checkInWaypoints(int points);
    void checkin(Game game,int points);
private:
    int points = 0;
};

#endif 
