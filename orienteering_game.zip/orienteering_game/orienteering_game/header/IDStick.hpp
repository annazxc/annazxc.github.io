#ifndef IDStick_hpp
#define IDStick_hpp
#include <vector>
#include <iostream>
#include <tuple>
#include <chrono>
#include "RunStatus.hpp"
class Course; 
class IDStick {
public:
    IDStick(){};
    IDStick(std::string name): Participant(name){
        SerialNumber = ++SerialNumberCounter;
    };
    IDStick(const std::vector<long>& serialNumbers);
    void printSerialNumbers() const;
    IDStick(const long& ,RunStatus);
    ~IDStick() = default;
    long getSerialNumber();
    void Display() const;
    
    void Register(const std::string& name, const Course& c);
    
    const Course* GetCurrentCourse() const;
    const std::vector<int>& GetVisitedWaypoints() const;
    void CheckWaypoint(int waypointIndex);

    std::tuple<int, std::string> Result() const;
    std::string GetParticipant() const {
            return Participant;
        }
    const std::vector<std::chrono::system_clock::time_point>& GetTimestamps()const {
            return Timestamps;
        }
    
    std::vector<std::chrono::system_clock::time_point> Timestamps;
    
    RunStatus runStatus;
    // static indicates each translation unit(src file) has their own copy, extern indicates only has one for all translation units.
    static std::vector<std::tuple<std::string,long,std::string,std::string >> Participants;//name,serialnum,course,waypointName
    static void AddParticipants(std::string name,long serialNum,std::string courseName,std::string waypointName){
        IDStick::Participants.emplace_back(name,serialNum,courseName,waypointName);
    }
    static std::vector<std::tuple<std::string,long,std::string,std::string >>getParticipants();
    static void DisplayParticipants();
    static void AddIDStick(IDStick id){
        IDStick::IDSticks.emplace_back(id);
    }
    static std::vector<IDStick>getIDSticks(){
        return IDStick::IDSticks;
    }
    static long getSerialNumberCounter() {
            return SerialNumberCounter;
        }
    //1 for successfully control a person,0 for just exit
    static std::tuple<int,std::string> controlParticipant(std::string& name) {
        int attempts = 0;
        const int maxAttempts = 3;
       while (attempts < maxAttempts) {
            bool participantFound = false;
            for (const auto& participant : Participants) {
                if (std::get<0>(participant) == name) {
                    std::cout << "Controlling participant: " << name << std::endl;
                    if(std::get<2>(participant)==""){
                        //name,serialnum,course,waypointName
                        std::cout<<"The participant has not registered for any course yet.\nPlease contact the registration center for more information.\nExiting the system..."<<std::endl;
                        return {0,""};
                    }
                    else{
                        std::cout << "The current enrolled course is: " <<std::get<2>(participant)<<std::endl;
                    }
                    participantFound = true;
                    break;
                }
            }
            
            if (participantFound) {
                return {1,name}; // If participant is found, exit the function
            }
            
            std::cerr << "Participant with name " << name << " not found." << "\nPlease retry:" << std::endl;
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cin >> name;
            attempts++;
        }
        
        std::cerr << "Maximum attempts reached. Exiting the system." << std::endl;
        return {0,""};
    }

private:
    static long SerialNumberCounter;
    std::vector<long> SerialNumbers;
    //std::vector<std::string> Participants;
    std::vector<Course*> Courses;
    //desire the CurrentCourse to be changeable and potentially null, use a pointer
    const Course* CurrentCourse;
    
    std::vector<std::string> Status;
    std::string Participant;
    void Signal(bool ok) const;
    std::pair<bool, int> UpdateStatus(int wayptnum) ;
    long SerialNumber;
    std::vector<int> VisitedWaypoints;
    static std::vector<IDStick>IDSticks;
};

#endif 
