#ifndef CourseList_hpp
#define CourseList_hpp
enum class CourseList{
    ForestChallenge=1,
    MountainQuest,
    LakesideAdventure,
    UrbanExplorer,
    DesertDiscovery
};
#endif
