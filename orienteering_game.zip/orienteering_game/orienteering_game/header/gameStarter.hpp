#ifndef gameStarter_hpp
#define gameStarter_hpp
#include"Course.hpp"
#include<vector>
#include<tuple>
class courseList {
public:
    static int setCourse();
    static void systemCourse(int userInput, std::vector<std::tuple<std::string, long, std::string, std::string>>&);
};
class gameStarter {
public:
    static void startGame();
    static void instruction();
    static void displayFunctions();
    static std::string begin();//return controlled participant
    static void Welcome();
    static void controlParticipant();
};


bool isValidName(const std::string& name);
bool isRepeatedName(const std::string& name);
class userDefCourse: public Course{
private:
    //courseName,DifficultyLevel,waypt
    static std::vector<Course>courses;
    static int userDefCoursesCounter;
public:
    bool static selfSetCourse();
    //0:exit,1 continue
    static void addCourse(Course c){
        courses.emplace_back(c);
        userDefCoursesCounter++;
    }
    static bool printUserDefCourse(Course c);
    static int getUserDefCoursesCounter();
    static int printCurrentUserDefCoursesNum();
    static void getMoreDetails();
    static std::vector<Course> getCourses();
};
#endif
