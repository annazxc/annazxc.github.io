CourseList:
1. ForestChallenge
w1 ={10, 20, 30, 40, 50}
2. MountainQuest
w2 ={15, 20, 35, 40, 55}
3. LakesideAdventure
w3 ={11, 22, 33, 44, 55}
4. UrbanExplorer
w4 ={13, 24, 35, 46, 57}
5. DesertDiscovery
w5 ={15, 24, 33, 42, 51}

- begin-->add participants and courses​
 - ask user to control a desired participant​
 - show some helpful function and the person's information​
- begin the ball game to determine if they get to check in the waypoint
- use IDStick to check in​
- involve some error handling​

---
​
# ball game
right player:participant, if score<=0 -->not able to check in waypt
hit esc to escape the game and close the window
press space to continue 
w to up, s to down

---
# more features
    //Congrat the participant when reach the final point of the course waypoint
    //print a certificate for finishing
    //resultTable: ranking,name,total time, correct check in points
    //Energy check():You are doing well so far! How exhausted are you?
    //timeDisplay(),current time and game terminate time
    //map(),tell the current location, and tell which direction to go next, tell remaining length to the next point
    //manageCourses()
    //showResults
    //heart rate
    //displayFunction(),call to display all the functionality in the game
    //add a point to the course()
    //ScoreCourse c3(course,DifficultyLevel::EASY, w3, points, std::chrono::seconds(3), 0.0);

    // Create leaderboards
