#include "Course.hpp"
#include"IDStick.hpp"
Course::Course(const std::string& name, DifficultyLevel lvl, const std::vector<int>& waypts)
    : Name(name), Level(lvl), Waypoints(waypts) {}


std::string Course::getName() const{
    return Name;
    
}
DifficultyLevel Course::getDifficultyLevel(){
    return Level;
}
   
const std::vector<int>& Course::getWaypoints() const{
    return Waypoints;
}

bool Course::checkWaypoint(const class IDStick& id, int wayptIdx)const{
    if (wayptIdx < Waypoints.size()) {
        if (id.GetCurrentCourse() == this) {
            // Get the waypoints the participant has visited
            const std::vector<int>& visitedWaypoints = id.GetVisitedWaypoints();
            
            // Check if the current waypoint is in the visited waypoints
            return std::find(visitedWaypoints.begin(), visitedWaypoints.end(), wayptIdx) != visitedWaypoints.end();
            
        }
    }
        // Either the waypoint index is invalid or the IDStick is not registered for this course
        return false;
}
std::string Course::difficultyLevelToString(DifficultyLevel level) {
    switch (level) {
        case DifficultyLevel::EASY:
            return "EASY";
        case DifficultyLevel::MEDIUM:
            return "MEDIUM";
        case DifficultyLevel::HARD:
            return "HARD";
        default:
            return "UNKNOWN";
    }
}
std::tuple<int, std::string, std::string> Course::ResultTable(const std::vector<std::chrono::system_clock::time_point>& timestamps) const {
        int score = 42;
        std::string scoreText = "Your Score: " + std::to_string(score);
        std::string tableText = "Table:";
        return {score, scoreText, tableText};
    }


    
    






