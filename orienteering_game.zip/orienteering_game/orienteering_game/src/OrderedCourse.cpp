#include "OrderedCourse.hpp"
#include"IDStick.hpp"
OrderedCourse::OrderedCourse(const std::string& name, DifficultyLevel& lvl, const std::vector<int>& waypts)
    : Course(name, lvl, waypts) {}

bool OrderedCourse::checkWaypoint(const class IDStick& id, int wayptIdx) const {
    // Get the index of the previous waypoint found
    auto timestamps = id.GetTimestamps();
    auto prevwpidx = std::max_element(timestamps.begin(), timestamps.end()) - timestamps.begin();
    // Current waypoint should be the next one
    return wayptIdx == (1 + prevwpidx);
}

std::tuple<int, std::string, std::vector<std::vector<int>>> OrderedCourse::ResultTable(const std::vector<int>& t) const {
    // Implementation of ResultTable method goes here
    // ...

    return std::make_tuple(0, "Score Text", std::vector<std::vector<int>>{}); // Replace with actual implementation
}

