#include"running.hpp"
void OrienteeringGame::InitCamera(Camera& camera, float fovy, Vector3 position, Vector3 target) {
    camera = { 0 };
    camera.fovy = fovy;
    camera.up.y = 1.0f;
    camera.target = target;
    camera.position = position;
}
void OrienteeringGame::InitRenderTexture(RenderTexture2D& renderTexture, int width, int height) {
    renderTexture = LoadRenderTexture(width, height);
}
void OrienteeringGame::ProcessInput(Camera& camera) {
    float offsetThisFrame = 10.0f * GetFrameTime();

    if (IsKeyDown(KEY_W)) {
        cameraPlayer1.position.z += offsetThisFrame;
        cameraPlayer1.target.z += offsetThisFrame;
    }
    if (IsKeyDown(KEY_S))
    {
        cameraPlayer1.position.z -= offsetThisFrame;
        cameraPlayer1.target.z -= offsetThisFrame;
    }
    if (IsKeyDown(KEY_D))
    {
        cameraPlayer1.position.x -= offsetThisFrame;
        cameraPlayer1.target.x -= offsetThisFrame;
    }
    if (IsKeyDown(KEY_A))
    {
        cameraPlayer1.position.x += offsetThisFrame;
        cameraPlayer1.target.x += offsetThisFrame;
    }

    //Player2
    if (IsKeyDown(KEY_UP))
    {
        cameraPlayer2.position.x += offsetThisFrame;
        cameraPlayer2.target.x += offsetThisFrame;
    }
    if (IsKeyDown(KEY_DOWN))
    {
        cameraPlayer2.position.x -= offsetThisFrame;
        cameraPlayer2.target.x -= offsetThisFrame;
    }
    if (IsKeyDown(KEY_LEFT))
    {
        cameraPlayer2.position.z -= offsetThisFrame;
        cameraPlayer2.target.z -= offsetThisFrame;
    }
    if (IsKeyDown(KEY_RIGHT))
    {
        cameraPlayer2.position.z += offsetThisFrame;
        cameraPlayer2.target.z += offsetThisFrame;
    }
}
void OrienteeringGame::DrawGame() {
    BeginTextureMode(screenPlayer1);
    // Draw player 1 view
    BeginTextureMode(screenPlayer1);
        ClearBackground(SKYBLUE);
        
        BeginMode3D(cameraPlayer1);
        
            // Draw scene
            DrawPlane((Vector3){ 0, 0, 0 }, (Vector2){ 80, 80 }, BEIGE);

            for (float x = -count*spacing; x <= count*spacing; x += spacing)
            {
                for (float z = -count*spacing; z <= count*spacing; z += spacing)
                {
                    DrawCube((Vector3) { x, 1.5f, z }, 1, 1, 1, LIME);
                    DrawCube((Vector3) { x, 0.5f, z }, 0.25f, 1, 0.25f, BROWN);
                }
            }

            //player's position
            DrawCube(cameraPlayer1.position, 1, 1, 1, RED);
            DrawCube(cameraPlayer2.position, 1, 1, 1, BLUE);
            DrawCube(Vector3{waypointG_X,waypointG_Y,waypointG_Z},2,2,2,GOLD);
            DrawCube(Vector3{waypointP_X,waypointP_Y,waypointP_Z},2,2,2,PINK);

        EndMode3D();
        
        DrawRectangle(0, 0, GetScreenWidth()/2, 40, Fade(RAYWHITE, 0.8f));
        DrawText("PLAYER-1 view (W/S/A/D to move)", 10, 10, 20, MAROON);
        
    EndTextureMode();

    //Player2
    BeginTextureMode(screenPlayer2);
        ClearBackground(SKYBLUE);
        
        BeginMode3D(cameraPlayer2);
        
            DrawPlane((Vector3){ 0, 0, 0 }, (Vector2){ 50, 50 }, BEIGE);

            for (float x = -count*spacing; x <= count*spacing; x += spacing)
            {
                for (float z = -count*spacing; z <= count*spacing; z += spacing)
                {
                    DrawCube((Vector3) { x, 1.5f, z }, 1, 1, 1, LIME);
                    DrawCube((Vector3) { x, 0.5f, z }, 0.25f, 1, 0.25f, BROWN);
                }
            }
            // Draw players
            DrawCube(cameraPlayer1.position, 1, 1, 1, RED);
            DrawCube(cameraPlayer2.position, 1, 1, 1, BLUE);
            DrawCube(Vector3{waypointG_X,waypointG_Y,waypointG_Z},2,2,2,GOLD);
            DrawCube(Vector3{waypointP_X,waypointP_Y,waypointP_Z},2,2,2,PINK);

    if(cameraPlayer1.position.x==waypointG_X&&cameraPlayer1.position.y==waypointG_Y&&cameraPlayer1.position.z==waypointG_Z){
        DrawText("Player 1 has reach the waypoint Gold(10)", 10, 10, 20, DARKBLUE);
        
    }
    if(cameraPlayer2.position.x==waypointG_X&&cameraPlayer1.position.y==waypointG_Y&&cameraPlayer1.position.z==waypointG_Z){
        DrawText("Player 2 has reach the waypoint Gold(10)", 10, 10, 20, DARKBLUE);
        
    }
    if(cameraPlayer1.position.x==waypointP_X&&cameraPlayer1.position.y==waypointP_Y&&cameraPlayer1.position.z==waypointP_Z){
        DrawText("Player 1 has reach the waypoint Pink(20)", 10, 10, 20, DARKBLUE);
        
    }
    if(cameraPlayer2.position.x==waypointP_X&&cameraPlayer1.position.y==waypointP_Y&&cameraPlayer1.position.z==waypointP_Z){
        DrawText("Player 2 has reach the waypoint Pink(20)", 10, 10, 20, DARKBLUE);
        
    }
        EndMode3D();
        
        DrawRectangle(0, 0, GetScreenWidth()/2, 40, Fade(RAYWHITE, 0.8f));
        DrawText("PLAYER-2 view(Up/Down/Left/Right to move)", 10, 10, 20, DARKBLUE);
        
    EndTextureMode();

    // Draw both views side by side
    BeginDrawing();
        ClearBackground(BLACK);
        
        DrawTextureRec(screenPlayer1.texture, splitScreenRect, (Vector2){ 0, 0 }, WHITE);
        DrawTextureRec(screenPlayer2.texture, splitScreenRect, (Vector2){ screenWidth/2.0f, 0 }, WHITE);
        
        DrawRectangle(GetScreenWidth()/2 - 2, 0, 4, GetScreenHeight(), LIGHTGRAY);
    EndDrawing();
}


