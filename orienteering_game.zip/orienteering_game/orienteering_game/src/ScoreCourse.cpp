#include "ScoreCourse.hpp"
#include"IDStick.hpp"
#include <chrono>

ScoreCourse::ScoreCourse(const std::string& name, DifficultyLevel& lvl, const std::vector<int>& waypts,const std::vector<int>& points, const std::chrono::seconds& maxtime, double penalty)
    : Course(name, lvl, waypts), Points(points), TimeLimit(maxtime), TimePenalty(penalty) {}

bool ScoreCourse::checkWaypoint(const class IDStick& id,  int wayptidx) const {
    bool ok = true;
    auto t = id.Timestamps;
    if (wayptidx > 1) {
        ok = ((std::chrono::system_clock::now() - t[0]) <= TimeLimit);
    }
    return ok;
}

/*std::tuple<int, std::string, std::vector<std::vector<int>>> ScoreCourse::ResultTable(const std::vector<int>& t) const {
    // Implementation of ResultTable method goes here
    // ...

    return std::make_tuple(0, "Score Text", std::vector<std::vector<int>>{}); // Replace with actual implementation
}

*/
