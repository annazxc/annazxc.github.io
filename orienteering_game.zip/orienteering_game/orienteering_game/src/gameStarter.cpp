#include "gameStarter.hpp"
#include"CourseList.hpp"
#include"IDStick.hpp"
#include"Course.hpp"
#include<thread>
#include<vector>
#include<iostream>
#include<limits>
#include<cctype>
void gameStarter::Welcome(){
    int userInput=-1;
    while(true){
        std::cout<<"This is an orienteering game for everyone.\nCustomize your own adventure, navigating and exploring diverse terrains.\nFeel free to contact us with any questions about the game.\nPlease enjoy!\n"<<std::endl;
        std::cout<<"Please enter how many users you would like to add : "<<std::endl;
        std::cin >> userInput;
        if(std::cin.fail()){
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout<<"Invalid input. Please submit again."<<std::endl;
        }
        else{
            break;
        }
        std::cerr<<"Exiting the system."<<std::endl;
        std::this_thread::sleep_for(std::chrono::seconds(3));
    }
    for(int i=0;i<userInput;i++){
        gameStarter::startGame();
        int a=courseList::setCourse();
        if(a==-1){
            std::cout<<"Now, the game will proceed to the next phase."<<std::endl;
            std::this_thread::sleep_for(std::chrono::seconds(2));
        }
        if(a==0){
            bool b=userDefCourse::selfSetCourse();//0:exit, 1:continue
            if(b==true){//1
                bool c=userDefCourse::printUserDefCourse(userDefCourse::getCourses().back());
                if(c==0){
                    
                }
                if(c==1){//participant name and course
                    std::tuple<std::string,long,std::string,std::string > i=IDStick::getParticipants().back();
                    //name,serialnum,course,waypointName
                    IDStick idstick=IDStick::getIDSticks().back();
                    Course c=userDefCourse::getCourses().back();
                    idstick.Register(std::get<0>(i),c);
                }
            }
            if(b==false){//0
                //do nothing
            }
        }
        else{
            courseList::systemCourse(a,IDStick::Participants);
            
        }
        
    }
    std::cout<<"Other participants are entering the game.\n"<<"Please wait for a moment."<<std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(3));
    const std::vector<int> w1 = {42, 123, 124, 163, 168, 666};
    const std::vector<int> w2 = {45, 13, 14, 17, 18, 66};
    Course c1("Nature Trail Trek",DifficultyLevel::MEDIUM,w1);
    Course c2("Wilderness Expedition Challenge",DifficultyLevel::HARD,w2);
    bool x=isRepeatedName("Peter");
    if(!x){
        IDStick id("Peter");
        id.Register("Peter", c1);
        id.Display();
        IDStick::AddParticipants("Peter",IDStick::getSerialNumberCounter(), "c1", "w1");
        std::this_thread::sleep_for(std::chrono::seconds(2));
    }
    bool x1=isRepeatedName("Susan");
    if(!x1){
        IDStick id1("Susan");
        id1.Register("Susan", c2);
        id1.Display();
        IDStick::AddParticipants("Susan",IDStick::getSerialNumberCounter(), "c2", "w2");
        
    }
}


void gameStarter::controlParticipant(){
    std::string name=gameStarter::begin();
    std::tuple<int,std::string> t;
    if(name!="Invalid input"){
        t=IDStick::controlParticipant(name);
        //1 for successfully control a person,0 for just exit
    }
    else{
        std::cout<<"Now, the game will proceed to the next phase."<<std::endl;
        std::this_thread::sleep_for(std::chrono::seconds(3));
    }
    if(std::get<0>(t)){//true control success
        
    }
    else{
        std::cout<<"Please reenter the name of the participant you would like to control.\nPlease note that this is case-sensitive to prevent you from controlling the wrong person.\nThe system will not accept your input if the case does not match."<<std::endl;
        std::string name;
        std::cin>>name;
        t=IDStick::controlParticipant(name);
        //1 for successfully control a person,0 for just exit
        if(std::get<0>(t)==0){
            std::cout<<"You are currently unable to match with a participant.\nPlease try again later.\nThe game will proceed, and in the meantime, you can participate as a guest.\nFeel free to wait until the current game finishes and then attempt contestant registration later."<<std::endl;
        }
    }
}
void gameStarter::startGame() {
       std::cout << "Welcome to the orienteering game!\nPlease enter a single-word name for your ID assignment:\nPlease notice that only the first word will be kept" << std::endl;

       std::string name;
       do {
           std::cin >> name;
           if (!isValidName(name)) {
               std::cerr << "Invalid input. Please enter a valid name containing only alphabetic characters.\n";
               std::cin.clear();
               std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
           } else if (isRepeatedName(name)) {
               std::cerr << "Name already exists. Please enter a different name.\n";
           }
       } while (!isValidName(name) || isRepeatedName(name));

    
    IDStick id(name);
    IDStick::AddIDStick(id);
    std::cout<<"Your ID number is:\n"<<id.getSerialNumber()<<std::endl;
    IDStick::AddParticipants(name,id.getSerialNumber(),"","");
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
   
    
}


std::vector<Course>userDefCourse::courses;
int userDefCourse::userDefCoursesCounter;
int userDefCourse::getUserDefCoursesCounter(){
    return userDefCoursesCounter;
}
bool isValidName(const std::string& name) {
    for (char c : name) {
        if (!std::isalpha(c)) {
            return false;
        }
    }
    return true;
}
bool isRepeatedName(const std::string& name) {
       auto it = std::find_if(IDStick::Participants.begin(), IDStick::Participants.end(),
                              [&](const auto& participant) {
                                  return std::get<0>(participant) == name;
                              });

       return it != IDStick::Participants.end();
   }

int courseList::setCourse(){
    std::cout<<"Which course would you like to register ?\nCurrently we have the following:\nPlease make your choice by entering 1~5"<<std::endl;
    std::cout << "1. Forest Challenge\n";
    std::cout << "2. Mountain Quest\n";
    std::cout << "3. Lakeside Adventure\n";
    std::cout << "4. Urban Explorer\n";
    std::cout << "5. Desert Discovery\n";
    std::cout<<"You may also set your own courses, please enter 0 if so"<<std::endl;
    std::cout<<"If you accidently input a non-integer, we would round it up for you."<<std::endl;
    int userInput = 6;
    for (int i = 0; i < 3; ++i) {
        std::cin >> userInput;
        if (std::cin.fail() || userInput < 0 || userInput > 5) {
            std::cerr << "Invalid input. Please enter a valid integer.\n";
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');  
        } else {
            std::cout << "You entered: " << userInput << std::endl;
            return userInput;
        }
    }
    
    std::cerr << "Maximum input attempts reached; exiting the setting." << std::endl;
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    return -1;
}

void courseList::systemCourse(int userInput,std::vector<std::tuple<std::string,long,std::string,std::string >>&Participants){
    
    switch (userInput) {
        case 1:{
            std::cout << "You have chosen course: Forest Challenge.\n";
            std::cout<<"The waypoints for this course are w1 ={10, 20, 30, 40, 50}"<<std::endl;
            
            std::get<2>(Participants.back())="Forest Challenge";
            //name,serialnum,course,waypointName
            std::get<3>(Participants.back())="w1";
            std::vector<int> waypts={10, 20, 30, 40, 50};
            Course c("Forest Challenge",DifficultyLevel::EASY,waypts);
            std::vector<IDStick> i=IDStick::getIDSticks();
            i.back().Register(std::get<0>(Participants.back()),c);
            std::cout<<"The difficulty level of this course is : EASY"<<std::endl;
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
           
            //新加的人一定為vector的最後一個
            break;}
        case 2:{
            std::cout << "You have chosen course: Mountain Quest.\n";
            std::cout<<"The waypoints for this course are w2 ={15, 20, 35, 40, 55}"<<std::endl;
            std::get<2>(Participants.back())="Mountain Quest";
            std::get<3>(Participants.back())="w2";
            std::vector<int> waypts={15, 20, 35, 40, 55};
            Course c("Mountain Quest",DifficultyLevel::MEDIUM,waypts);
            std::vector<IDStick> i=IDStick::getIDSticks();
            i.back().Register(std::get<0>(Participants.back()),c);
            std::cout<<"The difficulty level of this course is : MEDIUM"<<std::endl;
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
           
            break;}
        case 3:{
            std::cout << "You have chosen course: Lakeside Adventure.\n";
            std::cout<<"The waypoints for this course are w3 ={11, 22, 33, 44, 55}"<<std::endl;
            std::get<2>(Participants.back())="Lakeside Adventure";
            std::get<3>(Participants.back())="w3";
            std::vector<int> waypts={11, 22, 33, 44, 55};
            Course c("Lakeside Adventure",DifficultyLevel::MEDIUM,waypts);
            std::vector<IDStick> i=IDStick::getIDSticks();
            i.back().Register(std::get<0>(Participants.back()),c);
            std::cout<<"The difficulty level of this course is : MEDIUM"<<std::endl;
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
           
            break;}
        case 4:{
            std::cout << "You have chosen course: Urban Explorer.\n";
            std::cout<<"The waypoints for this course are w4 ={13, 24, 35, 46, 57}"<<std::endl;
            std::get<2>(Participants.back())="Urban Explorer";
            std::get<3>(Participants.back())="w4";
            std::vector<int> waypts={13, 24, 35, 46, 57};
            Course c("Urban Explorer",DifficultyLevel::EASY,waypts);
            std::vector<IDStick> i=IDStick::getIDSticks();
            i.back().Register(std::get<0>(Participants.back()),c);
            std::cout<<"The difficulty level of this course is : EASY"<<std::endl;
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
           
            break;}
        case 5:{
            std::cout << "You have chosen course: Desert Discovery.\n";
            std::cout<<"The waypoints for this course are w5 ={15, 24, 33, 42, 51}"<<std::endl;
            std::get<2>(Participants.back())="Desert Discovery";
            std::get<3>(Participants.back())="w5";
            std::vector<int> waypts={15, 24, 33, 42, 51};
            Course c("Desert Discovery",DifficultyLevel::HARD,waypts);
            std::vector<IDStick> i=IDStick::getIDSticks();
            i.back().Register(std::get<0>(Participants.back()),c);
            std::cout<<"The difficulty level of this course is : HARD"<<std::endl;
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
           
            break;}
        default:
            std::cerr << "Exiting the system...\nPlease wait for a moment.\n";
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
           
            break;
            
    }
    
}
//return 0--> exit userDefCourse, 1-->show more detail
int userDefCourse::printCurrentUserDefCoursesNum(){
    std::cout<<"Currently, there are " << userDefCourse::getUserDefCoursesCounter() << " user-defined courses. If you would like more details, please enter 1. Otherwise, enter 0 to exit the system."<<std::endl;
    int userInput=-1;
    std::cin>>userInput;
    if (std::cin.fail() || (userInput != 0 && userInput != 1)) {
        std::cerr << "Invalid input. Please enter a valid integer."<<std::endl;
        std::cin>>userInput;
    }
    if (std::cin.fail() || (userInput != 0 && userInput != 1)) {
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cerr << "Invalid input. Please enter a valid integer."<<std::endl;
        std::cin>>userInput;
    }
    if(userInput == 0 || userInput == 1) {
        switch(userInput){
            case 0:
                std::cout<<"You have entered 0, exiting the system."<<std::endl;
                return 0;
            case 1:
                std::cout<<"You have entered 1, here are some details."<<std::endl;
                return 1;
        }
    }
    std::cerr<<"Maximum input attempts reached; exiting the system."<<std::endl;
    return 0;
}
void userDefCourse::getMoreDetails(){
    std::cout<<"Here are all the user self-defined courses we have currently :\n"<<std::endl;
    for (Course course : userDefCourse::courses) {
                std::cout << "Course Name: " << course.getName() << std::endl;
        DifficultyLevel lvl=course.getDifficultyLevel();
                std::cout << "Difficulty Level: " <<Course::difficultyLevelToString(lvl)<<std::endl;
    }
    
}
//0:exit,1 continue
bool userDefCourse::selfSetCourse() {
    std::cout << "You may now start to set your own course.\nHow would you like to name your course?\nPlease provide a single word or use camel case to connect multiple words:\nPlease notice that only the first word will be kept" << std::endl;
//check
    std::string courseName;
    while (true) {
        std::cin >> courseName;
        if (courseName.find(' ') == std::string::npos ) {
            break;  // Valid input, exit the loop
        } else {
            std::cout << "Invalid input. Please provide a single word or use camel case to connect multiple words without spaces.\n";
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
    }

DifficultyLevel lvl;
    int userInput=-1;
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::cout<<"Please enter the desired difficult level: choose from {EASY, MEDIUM, HARD} by entering 1~3"<<std::endl;
    while (true) {
        if (std::cin >> userInput && userInput >= 1 && userInput <= 3) {
            lvl = static_cast<DifficultyLevel>(userInput);
            break;
        }
        else {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid input. Please enter a number between 1 and 3.\n";
        }
    }
    std::cout << "You have chosen difficulty level:"<<std::endl;
    switch(static_cast<int>(lvl)){
        case 1:
            {std::cout<<"EASY"<<std::endl;
                break;
            }
        case 2:
            {std::cout<<"MEDIUM"<<std::endl;
                break;
            }
        case 3:
            {std::cout<<"HARD"<<std::endl;
                break;
            }
   }
    int p1,p2,p3,p4,p5;
    //while 後方已順便輸入數值了
    int attempts = 0;
    const int maxAttempts = 3;
    
    while (attempts < maxAttempts) {
        std::cout<<"Please enter your desired waypoints(five integer,please use spaces to separte them), each route offers unique views :"<<std::endl;
        while (!(std::cin >> p1 >> p2 >> p3 >> p4 >> p5) || std::cin.peek() != '\n') {
            std::cerr << "Invalid input. Please enter five integers separated by spaces."<<std::endl;
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            
        }
        if (std::cin.good()) {
            std::vector<int>waypts={p1,p2,p3,p4,p5};
            Course c(courseName,lvl,waypts);
            userDefCourse::addCourse(c);
            return 1;
        } else {
            // Invalid input, increment attempts and try again
            attempts++;
            std::cerr << "Invalid input. Please try again.\n";
        }
    }
    std::cerr << "Maximum attempts reached. Exiting the system.\n";
    return 0;
}
std::vector<Course>userDefCourse::getCourses(){
    return courses;
}
//0:exit,1:register
bool userDefCourse::printUserDefCourse(Course c){
       int userInput=-1;
        std::vector<int>a=c.getWaypoints();
    std::cout<<"Here is the course you just defined:"<<std::endl;
    std::cout<<"Course Name : "<<c.getName()<<std::endl;
    std::cout<<"The difficulty level is : "<<Course::difficultyLevelToString(c.getDifficultyLevel())<<"\nThe waypoints are:\n"<<a[0]<<","<< a[1]<<","<< a[2]<<","<< a[3]<<","<< a[4]<<"\nWould you like to register now?\nEnter 1 for YES, 0 for NO"<<std::endl;
        std::cin>>userInput;
        if(userInput==0||userInput==1){
            return userInput;
        }
        else{
            std::cout<<"Invalid input. Please retry: "<<std::endl;
            std::cin>>userInput;
        }
        if(userInput==0||userInput==1){
            std::cin>>userInput;
            return userInput;
        }
        std::cerr<<"Maximum input reached, exiting the system."<<std::endl;
        return 0;
    }
std::string gameStarter::begin() {
    int attempts = 0;
    const int maxAttempts = 3;

    std::cout << "The adventure begins!\nGrab your essentials and ensure the IDStick accompanies you throughout the game.\nIt's your key to checking in at every waypoint.\nBest of luck for everyone! " << std::endl;

    while (attempts < maxAttempts) {
        std::cout << "Please enter the name of the participant you would like to control, using a single word:" << std::endl;
        std::string userInput;

        if (std::cin >> userInput && std::cin.get() == '\n') {
            // Valid input
            return userInput;
        } else {
            // Invalid input
            std::cerr << "Invalid input. Please enter a valid single-word name." << std::endl;
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            attempts++;
        }
    }
    std::cerr<<"Maximum attempts reached. Exiting the system."<<std::endl;
    return "Invalid input";
}

void gameStarter::instruction() {
    int userInput;
    while (true) {
        std::cout << "Enter 1 to view a list of helpful game functions or enter 0 to continue playing:\n";
        std::cin >> userInput;
        if (std::cin.fail() || (userInput != 0 && userInput != 1)) {
            std::cerr << "Invalid input. Please enter 0 or 1." << std::endl;
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        } else {
            break;
        }
    }
    if (userInput == 1) {
        gameStarter::displayFunctions();
    } else {
        return;
    }
}
void gameStarter::displayFunctions(){
    std::cout << "Here are some useful functions that might help you:\n"
              << "1. Map\n"
              << "2. Courses Management\n"
              << "3. Show Results\n"
              << "4. Heart Rate\n"
              << std::endl;
    std::cout<<"The game would automatically continue after few seconds."<<std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(6));
    
}
