#include <thread>
#include <limits>
#include "Course.hpp"
#include "OrderedCourse.hpp"
#include "ScoreCourse.hpp"
#include "IDStick.hpp"//chrono,tuple included
#include"gameStarter.hpp"
#include"CourseList.hpp"
#include"ballGame.hpp"//iostream
#include"running.hpp"

int main() {
    gameStarter::Welcome();
    IDStick::DisplayParticipants();
    std::this_thread::sleep_for(std::chrono::seconds(3));
    gameStarter::controlParticipant();
    gameStarter::instruction();
    OrienteeringGame gameO(1000, 500);
    gameO.Run();
    Game game;
    int points=game.Run();
    game.checkin(game,points);
    
    return 0;
}



