#include "IDStick.hpp"
#include"Course.hpp"
#include <algorithm>
#include <iomanip>
#include<iostream>

std::vector<std::tuple<std::string,long,std::string,std::string >>IDStick::getParticipants(){
    return Participants;
}
void IDStick::DisplayParticipants() {
    std::cout << "Currently, here is the list of participant names:\n";
    for (const auto& participant : Participants) {
        std::cout << "Name: " << std::get<0>(participant) << ", Serial Number: " << std::get<1>(participant) << std::endl;
    }
}
long IDStick::SerialNumberCounter=100000;
std::vector<std::tuple<std::string,long,std::string,std::string >>IDStick::Participants;//name,serialnum,course,waypointName
long IDStick::getSerialNumber(){
    return SerialNumber;
};
std::vector<IDStick> IDStick::IDSticks;
IDStick::IDStick(const long& snum,RunStatus status): SerialNumber(snum),runStatus (status) {}
IDStick::IDStick(const std::vector<long>& serialNumbers) : SerialNumbers(serialNumbers) {}

void IDStick::printSerialNumbers() const {
    std::cout << "Serial Numbers:";
    for (long serialNumber : SerialNumbers) {
        (void)serialNumber;
        std::cout << " " << SerialNumber;
    }
    std::cout << std::endl;
}

void IDStick::Display() const {
    std::cout << "ID stick #" << SerialNumberCounter;

    if (Participant.empty()) {
        std::cout << " which is not yet registered" << std::endl;
    }
    else {
        std::cout << " is registered to " << Participant << " who is ";
        if (runStatus ==RunStatus::Ready) {
            std::cout << "ready to run";
        } else if (runStatus == RunStatus::Running) {
            std::cout << "running";
        } else if (runStatus == RunStatus::Done) {
            std::cout << "finished with";
        }

        std::cout << std::endl;
        //check
        CurrentCourse->getName();//need to include Course, due to the need of accessing its function. if u only want to declare a Course pointer instead of using its function, then just use forward declaration to minimize the dependency of each file.
    }
}
//register is a keyword in c++
void IDStick::Register(const std::string& name, const Course& c) {
    Participant = name;
    CurrentCourse = &c;
    
    std::chrono::system_clock::time_point now = std::chrono::system_clock::now();
    std::time_t now_c = std::chrono::system_clock::to_time_t( now );
    //check
    Timestamps.resize(c.getWaypoints().size(),now);
    runStatus = RunStatus::Ready;
    Signal(true);
    std::cout<<"The IDStick is register now at "<<std::ctime( &now_c )<<"User's name :\n"<<Participant<<std::endl;
}

const Course* IDStick::GetCurrentCourse() const {
    return CurrentCourse;
}

const std::vector<int>& IDStick::GetVisitedWaypoints() const {
    return VisitedWaypoints;
}

void IDStick::CheckWaypoint(int wayptIndex) {
    // Assuming Waypoints is a vector of waypoint indices
    // Check if the waypoint index is within the valid range
    if (wayptIndex < CurrentCourse->getWaypoints().size()) {
        // Check if the IDStick is registered for this course
        if (CurrentCourse != nullptr) {
            // Check if the current waypoint is not already visited
            if (std::find(VisitedWaypoints.begin(), VisitedWaypoints.end(), wayptIndex) == VisitedWaypoints.end()) {
                // Mark the waypoint as visited
                VisitedWaypoints.push_back(wayptIndex);
            }
        }
    }
    // Ignore if the waypoint index is invalid or the IDStick is not registered for this course
}



std::tuple<int, std::string> IDStick::Result() const {
    if (runStatus == RunStatus::Done) {
        auto s = Timestamps[0];
        auto e = Timestamps.back();

        std::string txt = Participant + " (ID stick: " + std::to_string(SerialNumber) + ")\n";
        txt += "Course: " + CurrentCourse->getName() + "\n";
        txt += "Start time: " + std::to_string(std::chrono::duration_cast<std::chrono::seconds>(s.time_since_epoch()).count()) + "\n";

        auto [score, scoretxt, tbl] = CurrentCourse->ResultTable(Timestamps);
        txt += tbl + "\n";
        txt += "Finish time: " + std::to_string(std::chrono::duration_cast<std::chrono::seconds>(e.time_since_epoch()).count()) + "\n";
        txt += scoretxt;

        return {score, txt};
    } else {
        throw std::runtime_error("Cannot get results until the course is completed");
    }
}

void IDStick::Signal(bool ok) const{
    if (ok) {
        if (runStatus == RunStatus::Ready || runStatus ==RunStatus::Done) {
            std::cout << "Beep beep" << std::endl;
        } else {
            std::cout << "Beep" << std::endl;
        }
    } else {
        std::cout << "Buzz" << std::endl;
    }
}

std::pair<bool, int> IDStick::UpdateStatus(int wayptnum) {
    auto wplist = CurrentCourse->getWaypoints();
    auto it = std::find(wplist.begin(), wplist.end(), static_cast<int>(wayptnum));
    
    size_t idx = std::distance(wplist.begin(), it);
    
    if (runStatus == RunStatus::Error || runStatus == RunStatus::Done) {
        return {false, idx};
    } else if (runStatus == RunStatus::Ready) {
        if (idx == 0) {
            runStatus = RunStatus::Running;
            return {true, idx};
        } else {
            return {false, idx};
        }
    } else {
        bool ok = (it != wplist.end());
        if (ok && idx == wplist.size() - 1) {
            runStatus = RunStatus::Done;
        }
        return {ok, idx};
    }
}
