#include "ballGame.hpp"
#include "raylib.h"
#include"iostream"
#include"IDStick.hpp"
#include<chrono>
#include<thread>

int Game::Run() {
    InitWindow(800, 600, "Challenge");
    SetWindowState(FLAG_VSYNC_HINT);
    
    Ball ball(GetScreenWidth() / 2.0f, GetScreenHeight() / 2.0f, 100, 100, 10);
    
    Paddle leftPaddle(50, GetScreenHeight() * 0.5, 500, 10, 100);
    Paddle leftPaddle1(50, GetScreenHeight() * 0.25, 0, 10, 100);
    Paddle leftPaddle2(50, GetScreenHeight() * 0.75, 0, 10, 100);
    Paddle rightPaddle(GetScreenWidth() - 50, GetScreenHeight() / 2, 500, 10, 100);

    int points = 0;
    const char* winnerText = nullptr;
    bool pointAdded = false;

    while (!WindowShouldClose()) {
        ball.Update();
        leftPaddle.HandleInputL();
        rightPaddle.HandleInputR();

        ball.HandleCollisionL(leftPaddle);
        ball.HandleCollisionL(leftPaddle1);
        ball.HandleCollisionL(leftPaddle2);
        ball.HandleCollisionR(rightPaddle);

        HandleScore(ball, points, winnerText, pointAdded);

        DrawGame(ball, leftPaddle, leftPaddle1, leftPaddle2, rightPaddle, points, winnerText);
    }

    CloseWindow();

    return points;
}
void Game::checkin(Game game,int points){
    std::cout<<"Loading your challenge data, please wait!"<<std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(3));
    int a=game.checkInWaypoints(points);
    if(a>0){
        std::cout<<"Loading your challenge data, please wait!"<<std::endl;
        game.checkInWaypoints(a);
    }
    else{
        std::cout << "It looks like this challenge was tough, but don't worry!\nThe game will smoothly transition to the next phase.\nDon't give up – you've got this!" << std::endl;
    }
    
    
}
int Game::checkInWaypoints(int points){
   
    int IDnum=0;
    std::string courseName;
    if(points>0){
        std::cout<<"You have successfully conquered the challenge!\nPlease enter your ID serial number so that we can check you in at the waypoint."<<std::endl;
        std::cin>>IDnum;
        int attempts = 0;
        const int maxAttempts = 3;
        
        while (attempts < maxAttempts) {
            bool participantFound = false;
            
            for (const auto& participant : IDStick::Participants) {
                if (std::get<1>(participant) == IDnum) {
                    std::cout << "Valid input!\nYour input is: " << IDnum << std::endl;
                    std::cout << "Your current course is: " << std::get<2>(participant) << "\nThe waypoint has been checked!\nPlease continue your journey!" << std::endl;
                    participantFound = true;
                    break;
                }
            }
            
            if (!participantFound) {
                std::cout << "ID serial number not found\nPlease retry: " << std::endl;
                attempts++;
            } else {
                break;
            }
        }
        
    }
    else {
        char a;
        int attempts = 0;
        const int maxAttempts = 3;
        
        do {
            std::cout << "You have not been able to conquer the challenge!\nPlease retry or proceed to the next challenge!" << std::endl;
            std::cout << "Enter 'R' to retry or 'N' to proceed to the next challenge." << std::endl;
            std::cin >> a;
            
            if (a == 'R') {
                attempts++;
                Game game;
                points=game.Run();
                return points;
                
            } else if (a == 'N') {
                break;
            } else {
                std::cout << "Invalid input. Please enter 'R' to retry or 'N' to proceed." << std::endl;
            }
        } while (attempts < maxAttempts);
        
        if (attempts >= maxAttempts) {
            std::cout << "Maximum retry attempts reached. The game will proceed to the next phase automatically." << std::endl;
        }
        }
    
        return points;
}

void Ball::Reset() {
    x = GetScreenWidth() / 2.0f;
    y = GetScreenHeight() / 2.0f;
    radius = 10;
    speedX = 300;
    speedY = 300;
}

void Ball::Update() {
    x += speedX * GetFrameTime();
    y += speedY * GetFrameTime();

    if (y < 0) {
        y = 0;
        speedY *= -1;
    }

    if (y > GetScreenHeight()) {
        y = GetScreenHeight();
        speedY *= -1;
    }
}

void Paddle::HandleInputL() {
    if (IsKeyDown(KEY_W)) {
        y -= speed * GetFrameTime();
    }

    if (IsKeyDown(KEY_S)) {
        y += speed * GetFrameTime();
    }
    
}
void Paddle::HandleInputR(){
    if (IsKeyDown(KEY_UP)) {
        y -= speed * GetFrameTime();
    }

    if (IsKeyDown(KEY_DOWN)) {
        y += speed * GetFrameTime();
    }
}

void Ball::HandleCollisionL(const Paddle& paddle) {
    if (CheckCollisionCircleRec(Vector2{ x, y }, radius, paddle.GetRect())) {
        if (speedX < 0) {
            speedX *= -1.1f;
            speedY = (y - paddle.y) / (paddle.height / 2) * speedX;
        }
    }
}
void Ball::HandleCollisionR(const Paddle& paddle) {
    if (CheckCollisionCircleRec(Vector2{ x, y }, radius, paddle.GetRect())) {
        if (speedX > 0) {
            speedX *= -1.1f;
            speedY = (y - paddle.y) / (paddle.height / 2) * -speedX;
        }
    }
}


void Game::HandleScore(Ball& ball, int& points, const char*& winnerText, bool& pointAdded) {
    if (ball.x < 0) {
        if (!pointAdded) {
            winnerText = "You get a point!";
            points++;
            pointAdded = true;
        }
    } else if (ball.x > GetScreenWidth()) {
        if (!pointAdded) {
            winnerText = "You lose a point!";
            points--;
            pointAdded = true;
        }
    } else {
        pointAdded = false;
    }

    if (winnerText && IsKeyPressed(KEY_SPACE)) {
        ball.Reset();
        winnerText = nullptr;
    }
}

void Game::DrawGame(const Ball& ball, const Paddle& leftPaddle, const Paddle& leftPaddle1,
                    const Paddle& leftPaddle2, const Paddle& rightPaddle, int points, const char* winnerText) {
    static float rotation = 0.0f;
    rotation += 0.5f;
    static float rotation1 = 0.0f;
    rotation1 -= 0.5f;

    float recY = GetScreenHeight() * 0.5f;
    float recX = GetScreenWidth() / 2.0f;
    
    BeginDrawing();
        ClearBackground(BLACK);
        DrawRectanglePro(Rectangle{recX, recY + 100, 100, 20}, Vector2{50, 10}, rotation, GREEN);
        DrawRectanglePro(Rectangle{recX, recY, 50, 50}, Vector2{25, 25}, rotation, PINK);
        DrawRectanglePro(Rectangle{recX, recY - 100, 100, 20}, Vector2{50, 10}, rotation1, GREEN);

        ball.Draw();
        leftPaddle.DrawWithColor(BLUE);
        leftPaddle1.DrawWithColor(RED);
        leftPaddle2.Draw();
        rightPaddle.DrawWithColor(GREEN);

        int textWidth = MeasureText(winnerText, 60);
        if (winnerText) {
            DrawText(winnerText, GetScreenWidth() / 2 - textWidth / 2, GetScreenHeight() / 2 - 30, 60, YELLOW);
        }

        DrawText("Please hit esc to escape the game!", 355, 30, 20, YELLOW);
        DrawText("Your total score is:", 15, 30, 20, YELLOW);
        DrawText(std::to_string(points).c_str(), 220, 30, 20, YELLOW);
    EndDrawing();
}

