var searchData=
[
  ['update_0',['Update',['../class_ball.html#ac2f234d525c0fcf04334ac1d0acf5653',1,'Ball::Update()'],['../class_game.html#a1c5373c68261c54aff03e6abe40fee52',1,'Game::Update()']]]
];
