var searchData=
[
  ['speed_0',['speed',['../class_paddle.html#a062891d9cbb69f2312a9df62f18cdf5f',1,'Paddle']]],
  ['speedx_1',['speedX',['../class_ball.html#a1ef2a99048bf992a4768b080a6d8fa13',1,'Ball']]],
  ['speedy_2',['speedY',['../class_ball.html#a982887e4207b7a699f70752b57e1d741',1,'Ball']]]
];
