var searchData=
[
  ['game_0',['Game',['../md__r_e_a_d_m_e.html#autotoc_md1',1,'ball game'],['../class_game.html',1,'Game']]],
  ['gamestarter_1',['gameStarter',['../classgame_starter.html',1,'']]],
  ['gamestarter_2ecpp_2',['gameStarter.cpp',['../game_starter_8cpp.html',1,'']]],
  ['gamestarter_2ehpp_3',['gameStarter.hpp',['../game_starter_8hpp.html',1,'']]],
  ['getcourses_4',['getCourses',['../classuser_def_course.html#aaee61fc6029c896ea8554a4d8f2e12ad',1,'userDefCourse']]],
  ['getcurrentcourse_5',['GetCurrentCourse',['../class_i_d_stick.html#a99a733492993419390db243ec495038e',1,'IDStick']]],
  ['getdifficultylevel_6',['getDifficultyLevel',['../class_course.html#a1cede51b4d984066a03f2d9d18465fce',1,'Course']]],
  ['getidsticks_7',['getIDSticks',['../class_i_d_stick.html#a368baac00d784526a00e5187f0e90a78',1,'IDStick']]],
  ['getmoredetails_8',['getMoreDetails',['../classuser_def_course.html#ad7605b8af4b62cc7d379a0ebf72f4366',1,'userDefCourse']]],
  ['getname_9',['getName',['../class_course.html#ab26b47d93027fcecffdf42b2ee526f87',1,'Course']]],
  ['getparticipant_10',['GetParticipant',['../class_i_d_stick.html#a280c18a70a056b8c191edb2a5663c94a',1,'IDStick']]],
  ['getparticipants_11',['getParticipants',['../class_i_d_stick.html#a8c8a5cd12d35cb3af31d615ddf30d4bf',1,'IDStick']]],
  ['getrect_12',['GetRect',['../class_paddle.html#aa33ca0c9a574ad83b9e6dab6604dfdea',1,'Paddle']]],
  ['getserialnumber_13',['getSerialNumber',['../class_i_d_stick.html#acc0cc9e68337c54b9ffda330eec6bf9c',1,'IDStick']]],
  ['getserialnumbercounter_14',['getSerialNumberCounter',['../class_i_d_stick.html#abe7ff5d9b9c802ecf52f611a771e9fce',1,'IDStick']]],
  ['gettimestamps_15',['GetTimestamps',['../class_i_d_stick.html#a209230d6f4e994cc919cf4efe8439adb',1,'IDStick']]],
  ['getuserdefcoursescounter_16',['getUserDefCoursesCounter',['../classuser_def_course.html#a13617eb0b7890923d76725ba449bc954',1,'userDefCourse']]],
  ['getvisitedwaypoints_17',['GetVisitedWaypoints',['../class_i_d_stick.html#a819b31887be4b100527c3affb2e901aa',1,'IDStick']]],
  ['getwaypoints_18',['getWaypoints',['../class_course.html#aa48041e2ab41588a695156e6dd786886',1,'Course']]]
];
