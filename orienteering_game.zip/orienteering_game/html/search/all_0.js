var searchData=
[
  ['addcourse_0',['addCourse',['../classuser_def_course.html#ac9abb676c05d291cea84d2057e08b86c',1,'userDefCourse']]],
  ['addidstick_1',['AddIDStick',['../class_i_d_stick.html#a8b49b8df2cdddb13693acede24944994',1,'IDStick']]],
  ['addparticipants_2',['AddParticipants',['../class_i_d_stick.html#abfb8e927ea376139c8faf500d7c06e1b',1,'IDStick']]]
];
