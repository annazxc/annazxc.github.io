var searchData=
[
  ['radius_0',['radius',['../class_ball.html#a86bfb032007c736e06c2295a8070d620',1,'Ball']]],
  ['runstatus_1',['runStatus',['../class_i_d_stick.html#a45986a4952832fe3aab04eebcb914103',1,'IDStick']]]
];
