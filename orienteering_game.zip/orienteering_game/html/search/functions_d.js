var searchData=
[
  ['welcome_0',['Welcome',['../classgame_starter.html#a4b8adef6ac2b2c0ee3b64ff9bd228793',1,'gameStarter']]]
];
