var searchData=
[
  ['userdefcourse_0',['userDefCourse',['../classuser_def_course.html',1,'']]]
];
