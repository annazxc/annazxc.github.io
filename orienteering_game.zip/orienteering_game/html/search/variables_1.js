var searchData=
[
  ['level_0',['Level',['../class_course.html#acd60fa27d7dc2dfe4d0d3cd5f6dc80c9',1,'Course']]]
];
