var searchData=
[
  ['game_0',['Game',['../class_game.html',1,'']]],
  ['gamestarter_1',['gameStarter',['../classgame_starter.html',1,'']]]
];
