var searchData=
[
  ['waypoints_0',['Waypoints',['../class_course.html#ab178ccc19a0a1eb5e7935dd9d4b6ed9e',1,'Course']]],
  ['width_1',['width',['../class_paddle.html#a7052f2faf346bc04ee2be563a2e5a6e4',1,'Paddle']]]
];
