var searchData=
[
  ['idstick_0',['IDStick',['../class_i_d_stick.html#a2ce5b51fb11eebefc8a55002bc575c6b',1,'IDStick::IDStick()'],['../class_i_d_stick.html#a2736af3049d394c54d54ed02ad3bcade',1,'IDStick::IDStick(std::string name)'],['../class_i_d_stick.html#ac082ab6b7b00fdefe37d822cf00605fb',1,'IDStick::IDStick(const std::vector&lt; long &gt; &amp;serialNumbers)'],['../class_i_d_stick.html#a7670215db4ef32a02268a3f5fc4322a9',1,'IDStick::IDStick(const long &amp;, RunStatus)']]],
  ['instruction_1',['instruction',['../classgame_starter.html#ac37766f327e6a6abef537db45c8065dc',1,'gameStarter']]],
  ['isrepeatedname_2',['isRepeatedName',['../game_starter_8hpp.html#ac2c5a1492ad58fe9dd29882d407e3ca9',1,'isRepeatedName(const std::string &amp;name):&#160;gameStarter.cpp'],['../game_starter_8cpp.html#ac2c5a1492ad58fe9dd29882d407e3ca9',1,'isRepeatedName(const std::string &amp;name):&#160;gameStarter.cpp']]],
  ['isvalidname_3',['isValidName',['../game_starter_8hpp.html#a4809556bc9e3febff90ce54f7d930096',1,'isValidName(const std::string &amp;name):&#160;gameStarter.cpp'],['../game_starter_8cpp.html#a4809556bc9e3febff90ce54f7d930096',1,'isValidName(const std::string &amp;name):&#160;gameStarter.cpp']]]
];
