var searchData=
[
  ['name_0',['Name',['../class_course.html#a396354ba7515dd88cfa72d0d953ae106',1,'Course']]]
];
