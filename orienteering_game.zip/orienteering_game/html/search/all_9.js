var searchData=
[
  ['lakesideadventure_0',['LakesideAdventure',['../_course_list_8hpp.html#a2af66d34a168439334772947b79464c2aaf29411e80f9413a59bf45aa13a2e9eb',1,'CourseList.hpp']]],
  ['level_1',['Level',['../class_course.html#acd60fa27d7dc2dfe4d0d3cd5f6dc80c9',1,'Course']]]
];
