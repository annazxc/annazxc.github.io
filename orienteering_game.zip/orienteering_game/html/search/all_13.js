var searchData=
[
  ['x_0',['x',['../class_ball.html#a024a44a6a49c92e2172c294563f6a149',1,'Ball::x'],['../class_paddle.html#a67ce75080100e6858c0536478a7f9c04',1,'Paddle::x']]]
];
