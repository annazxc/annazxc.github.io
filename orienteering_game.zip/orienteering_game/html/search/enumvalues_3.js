var searchData=
[
  ['hard_0',['HARD',['../_course_8hpp.html#a1df741c634b332657f7873c5de587db5a7c144eae2e08db14c82e376603cc01f4',1,'Course.hpp']]]
];
