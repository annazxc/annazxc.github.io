var searchData=
[
  ['y_0',['y',['../class_ball.html#a554b27b87bb6c7bc838855e84389c4fb',1,'Ball::y'],['../class_paddle.html#a0c875960ccfddbe66ccf9f7b9f94267a',1,'Paddle::y']]]
];
